package com.example.tp_benitez_samaniego.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.tp_benitez_samaniego.R
import com.example.tp_benitez_samaniego.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val viewModel: HomeViewModel by viewModels()

    private val adapter = TareaAdapter(
        onEliminar = { tarea -> viewModel.eliminarTarea(tarea) },
        onCompletar = { tarea, marcada -> viewModel.cambiarCompletada(tarea, marcada) }
    )

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val usuario = requireArguments().getString("usuario").orEmpty()
        viewModel.setUsuario(usuario)

        binding.tvUserData.text = "¡Hola, $usuario!\nHas iniciado sesión correctamente."

        binding.recyclerTareas.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerTareas.adapter = adapter

        viewModel.tareas.observe(viewLifecycleOwner) { lista ->
            adapter.submitList(lista) {
                adapter.notifyItemRangeChanged(0, adapter.itemCount)
            }
            if (lista.isEmpty()) {
                binding.tvSinTareas.visibility = View.VISIBLE
            } else {
                binding.tvSinTareas.visibility = View.GONE
            }
        }

        binding.toolbar.inflateMenu(R.menu.menu_home)
        binding.toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.menu_inicio -> {
                    binding.scrollHome.smoothScrollTo(0, 0)
                    true
                }
                R.id.menu_borrar_todas -> {
                    viewModel.eliminarTodas()
                    true
                }
                R.id.menu_cerrar_sesion -> {
                    findNavController().navigate(R.id.action_home_to_login)
                    true
                }
                else -> false
            }
        }

        binding.btnGuardarTarea.setOnClickListener { guardarTarea() }
    }

    private fun guardarTarea() {
        val titulo = binding.etTituloTarea.text.toString().trim()
        val fecha = binding.etFechaTarea.text.toString().trim()
        val descripcion = binding.etDescripcionTarea.text.toString().trim()

        if (titulo.isEmpty() || fecha.isEmpty() || descripcion.isEmpty()) {
            Toast.makeText(requireContext(), "Completá todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        viewModel.guardarTarea(titulo, fecha, descripcion)

        binding.etTituloTarea.text?.clear()
        binding.etFechaTarea.text?.clear()
        binding.etDescripcionTarea.text?.clear()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding.recyclerTareas.adapter = null
        _binding = null
    }
}
