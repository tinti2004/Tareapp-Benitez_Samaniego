package com.example.tp_benitez_samaniego.ui

import android.database.sqlite.SQLiteConstraintException
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.tp_benitez_samaniego.data.AppDatabase
import com.example.tp_benitez_samaniego.data.Usuario
import com.example.tp_benitez_samaniego.databinding.FragmentRegisterBinding
import kotlinx.coroutines.launch

class RegisterFragment : Fragment() {

    private var _binding: FragmentRegisterBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRegisterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val sugerido = arguments?.getString("usuario")
        if (savedInstanceState == null && !sugerido.isNullOrEmpty()) {
            binding.etUser.setText(sugerido)
        }

        binding.btnRegister.setOnClickListener { registrar() }
    }

    private fun registrar() {
        val user = binding.etUser.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()

        if (user.isBlank() || password.isBlank()) {
            Toast.makeText(requireContext(), "Por Favor Complete Todos Los Campos", Toast.LENGTH_SHORT).show()
            return
        }

        val dao = AppDatabase.getInstance(requireContext()).usuarioDao()

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                dao.insertar(Usuario(user, password))
                Toast.makeText(requireContext(), "Registro Exitoso", Toast.LENGTH_SHORT).show()
                findNavController().popBackStack()
            } catch (e: SQLiteConstraintException) {
                Toast.makeText(requireContext(), "Ya Existe Una Cuenta Con Ese Usuario", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
