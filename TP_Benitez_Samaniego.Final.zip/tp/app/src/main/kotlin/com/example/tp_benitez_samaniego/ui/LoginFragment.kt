package com.example.tp_benitez_samaniego.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.tp_benitez_samaniego.R
import com.example.tp_benitez_samaniego.data.AppDatabase
import com.example.tp_benitez_samaniego.databinding.FragmentLoginBinding
import kotlinx.coroutines.launch

class LoginFragment : Fragment() {

    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.editTextUsuario.setOnFocusChangeListener { _, tieneFoco ->
            binding.editTextUsuario.hint = if (tieneFoco) "" else getString(R.string.usuario)
        }

        binding.editTextClave.setOnFocusChangeListener { _, tieneFoco ->
            binding.editTextClave.hint = if (tieneFoco) "" else getString(R.string.clave)
        }

        binding.button.setOnClickListener { iniciarSesion() }

        binding.buttonCrearCuenta.setOnClickListener {
            findNavController().navigate(
                R.id.action_login_to_register,
                bundleOf("usuario" to binding.editTextUsuario.text.toString().trim())
            )
        }
    }

    private fun iniciarSesion() {
        val usuario = binding.editTextUsuario.text.toString().trim()
        val clave = binding.editTextClave.text.toString().trim()

        if (usuario.isBlank() || clave.isBlank()) {
            Toast.makeText(requireContext(), "Rellene Los Campos Requeridos", Toast.LENGTH_SHORT).show()
            return
        }

        val dao = AppDatabase.getInstance(requireContext()).usuarioDao()

        viewLifecycleOwner.lifecycleScope.launch {
            val guardado = dao.buscar(usuario)

            if (guardado != null && guardado.password == clave) {
                Toast.makeText(requireContext(), "Bienvenido $usuario", Toast.LENGTH_SHORT).show()
                findNavController().navigate(
                    R.id.action_login_to_home,
                    bundleOf("usuario" to usuario)
                )
            } else {
                Toast.makeText(requireContext(), "Usuario o Clave Incorrectos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
