package com.example.tp_benitez_samaniego.ui

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.tp_benitez_samaniego.data.Tarea
import com.example.tp_benitez_samaniego.databinding.ItemTareaBinding

class TareaAdapter(
    private val onEliminar: (Tarea) -> Unit,
    private val onCompletar: (Tarea, Boolean) -> Unit
) : ListAdapter<Tarea, TareaAdapter.TareaViewHolder>(DiffCallback) {

    inner class TareaViewHolder(private val binding: ItemTareaBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(tarea: Tarea, numero: Int) {
            binding.tvTitulo.text = "$numero. ${tarea.titulo}"
            binding.tvFecha.text = "Fecha de entrega: ${tarea.fecha}"
            binding.tvDescripcion.text = "Descripción\n${tarea.descripcion}"

            binding.cbCompletada.setOnCheckedChangeListener(null)
            binding.cbCompletada.isChecked = tarea.completada
            tachar(tarea.completada)

            binding.cbCompletada.setOnCheckedChangeListener { _, marcada ->
                onCompletar(tarea, marcada)
            }
            binding.tvEliminar.setOnClickListener { onEliminar(tarea) }
        }

        private fun tachar(completada: Boolean) {
            if (completada) {
                binding.tvTitulo.paintFlags = binding.tvTitulo.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            } else {
                binding.tvTitulo.paintFlags = binding.tvTitulo.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TareaViewHolder {
        val binding = ItemTareaBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TareaViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TareaViewHolder, position: Int) {
        holder.bind(getItem(position), position + 1)
    }

    private object DiffCallback : DiffUtil.ItemCallback<Tarea>() {
        override fun areItemsTheSame(a: Tarea, b: Tarea) = a.id == b.id
        override fun areContentsTheSame(a: Tarea, b: Tarea) = a == b
    }
}
