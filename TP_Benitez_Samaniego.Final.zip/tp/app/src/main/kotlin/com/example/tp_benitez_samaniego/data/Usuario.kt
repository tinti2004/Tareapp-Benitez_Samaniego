package com.example.tp_benitez_samaniego.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "usuarios")
data class Usuario(
    @PrimaryKey val username: String,
    val password: String
)
