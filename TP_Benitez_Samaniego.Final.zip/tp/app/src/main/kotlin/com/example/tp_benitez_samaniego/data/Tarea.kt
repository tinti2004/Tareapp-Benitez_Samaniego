package com.example.tp_benitez_samaniego.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tareas")
data class Tarea(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val usuario: String,
    val titulo: String,
    val fecha: String,
    val descripcion: String,
    @ColumnInfo(defaultValue = "0") val completada: Boolean = false
)
