package com.example.tp_benitez_samaniego.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.switchMap
import androidx.lifecycle.viewModelScope
import com.example.tp_benitez_samaniego.data.AppDatabase
import com.example.tp_benitez_samaniego.data.Tarea
import kotlinx.coroutines.launch

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val tareaDao = AppDatabase.getInstance(application).tareaDao()

    private val usuario = MutableLiveData<String>()

    val tareas: LiveData<List<Tarea>> = usuario.switchMap { nombre ->
        tareaDao.obtenerTareas(nombre).asLiveData()
    }

    fun setUsuario(nombre: String) {
        if (usuario.value != nombre) {
            usuario.value = nombre
        }
    }

    fun guardarTarea(titulo: String, fecha: String, descripcion: String) {
        val nombre = usuario.value ?: return
        viewModelScope.launch {
            tareaDao.insertar(
                Tarea(usuario = nombre, titulo = titulo, fecha = fecha, descripcion = descripcion)
            )
        }
    }

    fun cambiarCompletada(tarea: Tarea, completada: Boolean) {
        viewModelScope.launch { tareaDao.actualizar(tarea.copy(completada = completada)) }
    }

    fun eliminarTarea(tarea: Tarea) {
        viewModelScope.launch { tareaDao.eliminar(tarea) }
    }

    fun eliminarTodas() {
        val nombre = usuario.value ?: return
        viewModelScope.launch { tareaDao.eliminarTodas(nombre) }
    }
}
