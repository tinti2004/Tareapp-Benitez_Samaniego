package com.example.tp_benitez_samaniego

import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

class HomeActivity : AppCompatActivity() {

    private val tareas = mutableListOf<Tarea>()

    private val preferencias by lazy {
        getSharedPreferences("TareasPrefs", MODE_PRIVATE)
    }

    private lateinit var listaTareas: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val usuario = getSharedPreferences("UserPrefs", MODE_PRIVATE)
            .getString("Username", "Usuario")

        findViewById<TextView>(R.id.tvUserData).text =
            "¡Hola, $usuario!\nHas iniciado sesión correctamente."

        listaTareas = findViewById(R.id.listaTareas)

        val titulo = findViewById<EditText>(R.id.etTituloTarea)
        val fecha = findViewById<EditText>(R.id.etFechaTarea)
        val descripcion = findViewById<EditText>(R.id.etDescripcionTarea)

        cargarTareas()
        mostrarTareas()

        findViewById<Button>(R.id.btnGuardarTarea).setOnClickListener {
            val t = titulo.text.toString().trim()
            val f = fecha.text.toString().trim()
            val d = descripcion.text.toString().trim()

            if (t.isEmpty() || f.isEmpty() || d.isEmpty()) {
                Toast.makeText(
                    this, "Completá todos los campos",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                tareas.add(Tarea(t, f, d))
                guardarTareas()
                mostrarTareas()

                titulo.text.clear()
                fecha.text.clear()
                descripcion.text.clear()
            }
        }

        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }
    }

    private fun guardarTareas() {
        val datos = JSONArray()

        tareas.forEach {
            datos.put(JSONObject().apply {
                put("titulo", it.titulo)
                put("fecha", it.fecha)
                put("descripcion", it.descripcion)
            })
        }

        preferencias.edit()
            .putString("lista_tareas", datos.toString())
            .apply()
    }

    private fun cargarTareas() {
        val datos = JSONArray(
            preferencias.getString("lista_tareas", "[]")
        )

        for (i in 0 until datos.length()) {
            val obj = datos.getJSONObject(i)

            tareas.add(
                Tarea(
                    obj.getString("titulo"),
                    obj.getString("fecha"),
                    obj.getString("descripcion")
                )
            )
        }
    }

    private fun mostrarTareas() {
        listaTareas.removeAllViews()

        tareas.forEach { tarea ->
            val tarjeta = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(24, 24, 24, 24)
                background = GradientDrawable().apply {
                    setColor(getColor(R.color.white))
                    cornerRadius = 30f
                    setStroke(2, getColor(R.color.rosa_intenso))
                }
            }

            val fila = LinearLayout(this).apply {
                gravity = android.view.Gravity.CENTER_VERTICAL
            }

            val titulo = TextView(this).apply {
                text = tarea.titulo
                textSize = 20f
                setTextColor(getColor(R.color.rosa_intenso))
                setTypeface(null, Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
            }

            val eliminar = TextView(this).apply {
                text = "✕"
                textSize = 24f
                setTextColor(getColor(R.color.rosa_intenso))
                setPadding(12, 0, 0, 0)
                setOnClickListener {
                    tareas.remove(tarea)
                    guardarTareas()
                    mostrarTareas()
                }
            }

            fila.addView(titulo)
            fila.addView(eliminar)

            val fecha = TextView(this).apply {
                text = "Fecha de entrega: ${tarea.fecha}"
                textSize = 14f
                setTextColor(getColor(R.color.black))
                setPadding(0, 12, 0, 16)
            }

            val descripcion = TextView(this).apply {
                text = "Descripción\n${tarea.descripcion}"
                textSize = 16f
                setTextColor(getColor(R.color.black))
            }

            tarjeta.addView(fila)
            tarjeta.addView(fecha)
            tarjeta.addView(descripcion)

            val margen = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            margen.setMargins(0, 0, 0, 24)

            listaTareas.addView(tarjeta, margen)
        }
    }
}




