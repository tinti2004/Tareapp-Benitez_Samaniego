package com.example.tp_benitez_samaniego

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.tp_benitez_samaniego.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.editTextUsuario.setOnFocusChangeListener { _, tieneFoco ->
            if (tieneFoco) {
                binding.editTextUsuario.hint = ""
            } else {
                binding.editTextUsuario.hint = getString(R.string.usuario)
            }
        }

        binding.editTextClave.setOnFocusChangeListener { _, tieneFoco ->
            if (tieneFoco) {
                binding.editTextClave.hint = ""
            } else {
                binding.editTextClave.hint = getString(R.string.clave)
            }
        }

        binding.button.setOnClickListener {
            val usuario = binding.editTextUsuario.text.toString().trim()
            val clave = binding.editTextClave.text.toString().trim()

            if (usuario.isBlank() || clave.isBlank()) {
                Toast.makeText(
                    this,
                    "Rellene Los Campos Requeridos",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            val preferencias = getSharedPreferences("UserPrefs", MODE_PRIVATE)
            val usuarioGuardado = preferencias.getString("Username", "")
            val claveGuardada = preferencias.getString("password", "")

            if (usuario == usuarioGuardado && clave == claveGuardada) {
                val intent = Intent(this, HomeActivity::class.java)
                startActivity(intent)

                Toast.makeText(
                    this,
                    "Bienvenido $usuario",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(
                    this,
                    "Usuario o Clave Incorrectos",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        binding.buttonCrearCuenta.setOnClickListener {
            val intent = Intent(this, RegisterActivity2::class.java)
            startActivity(intent)
        }
    }
}
