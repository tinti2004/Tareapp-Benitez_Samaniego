package com.example.tp_benitez_samaniego

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegisterActivity2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val etUser = findViewById<EditText>(R.id.etUser)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnRegister = findViewById<Button>(R.id.btnRegister)

        val usuarioIngresado = intent.getStringExtra("username")

        if (!usuarioIngresado.isNullOrEmpty()) {
            etUser.setText(usuarioIngresado)
        }

        btnRegister.setOnClickListener {
            val user = etUser.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (user.isBlank() || password.isBlank()) {
                Toast.makeText(
                    this,
                    "Por Favor Complete Todos Los Campos",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            val preferencias = getSharedPreferences("UserPrefs", MODE_PRIVATE)

            if (preferencias.contains("Username")) {
                Toast.makeText(
                    this,
                    "Ya Existe Una Cuenta",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            preferencias.edit()
                .putString("Username", user)
                .putString("password", password)
                .apply()

            Toast.makeText(
                this,
                "Registro Exitoso",
                Toast.LENGTH_SHORT
            ).show()

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}

