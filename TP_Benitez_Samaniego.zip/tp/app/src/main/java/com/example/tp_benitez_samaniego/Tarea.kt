package com.example.tp_benitez_samaniego

import android.graphics.Color

data class Tarea(
    val titulo: String,
    val fecha: String,
    val descripcion: String,
)