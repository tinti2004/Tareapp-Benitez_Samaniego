package com.example.tp_benitez_samaniego

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.tp_benitez_samaniego.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        //setContentView(R.layout.activity_main)
        setContentView(binding.root)

        val user = findViewById<EditText>(R.id.editTextUsuario)
        val contraseña = findViewById<EditText>(R.id.editTextContraseña)
        val button = findViewById<Button>(R.id.button)


        binding.button.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            intent.putExtra("username", binding.editTextUsuario.text.toString())
            startActivity(intent)
            Toast.makeText(this, "Bienvenido ${binding.editTextUsuario.text}", Toast.LENGTH_SHORT).show()
        }






        }
    }

